import { useState, useEffect } from 'react';
import { X, Send, FlaskConical } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getLabs, createLab, createLabTransfer } from '../../firebase/firestoreService';
import type { Lab, Patient, ToothState } from '../../types';

interface Props {
  patient: Patient;
  toothId: string;
  toothState: ToothState;
  onClose: () => void;
  onTransferred: (labId: string, labName: string, transferId: string) => void;
}

export function LabTransferModal({ patient, toothId, toothState, onClose, onTransferred }: Props) {
  const { clinicId, userProfile } = useAuth();
  const [labs, setLabs] = useState<Lab[]>([]);
  const [selectedLabId, setSelectedLabId] = useState('');
  const [newLabName, setNewLabName] = useState('');
  const [showNewLab, setShowNewLab] = useState(false);
  const [notes, setNotes] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!clinicId) return;
    const list = getLabs(clinicId);
    setLabs(list);
    setShowNewLab(list.length === 0);
  }, [clinicId]);

  const handleAddLab = () => {
    if (!clinicId || !newLabName.trim()) return;
    const lab = createLab({ clinicId, name: newLabName.trim() });
    setLabs((l) => [...l, lab]);
    setSelectedLabId(lab.id);
    setNewLabName('');
    setShowNewLab(false);
  };

  const handleSend = () => {
    if (!clinicId || !selectedLabId) return;
    const lab = labs.find((l) => l.id === selectedLabId);
    if (!lab) return;
    setSending(true);
    const transfer = createLabTransfer({
      clinicId,
      labId: lab.id,
      labName: lab.name,
      patientId: patient.id,
      patientName: patient.fullName,
      patientFileNumber: patient.fileNumber,
      toothId,
      diagnosis: toothState.diagnosis || toothState.notes || '',
      amount: toothState.amount ?? 0,
      totalSessions: toothState.totalSessions ?? 1,
      completedSessions: toothState.completedSessions ?? [],
      notes,
      createdBy: userProfile?.displayName ?? 'طبيب',
      patientSnapshot: {
        fullName: patient.fullName,
        phoneNumber: patient.phoneNumber,
        fileNumber: patient.fileNumber,
        chronicDiseases: patient.chronicDiseases,
        allergies: patient.allergies,
      },
    });
    onTransferred(lab.id, lab.name, transfer.id);
    setSending(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" dir="rtl">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-purple-600" />
            <h3 className="font-bold text-slate-800 dark:text-white">تحويل السن {toothId} إلى المعمل</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-5 space-y-4">
          {!showNewLab ? (
            <>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">اختر المعمل</label>
                <select
                  value={selectedLabId}
                  onChange={(e) => setSelectedLabId(e.target.value)}
                  className="w-full border border-slate-200 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="">— اختر —</option>
                  {labs.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                </select>
              </div>
              <button type="button" onClick={() => setShowNewLab(true)} className="text-xs text-purple-600 hover:underline">
                + إضافة معمل جديد
              </button>
            </>
          ) : (
            <div className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-3 space-y-2">
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">اسم المعمل الجديد</label>
              <input
                value={newLabName}
                onChange={(e) => setNewLabName(e.target.value)}
                placeholder="مثال: معمل النور للأسنان"
                className="w-full border border-slate-200 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <div className="flex gap-2">
                <button type="button" onClick={handleAddLab} className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold py-2 rounded-lg transition">
                  إضافة واختيار
                </button>
                {labs.length > 0 && (
                  <button type="button" onClick={() => setShowNewLab(false)} className="px-3 py-2 rounded-lg bg-slate-200 dark:bg-slate-600 text-xs text-slate-700 dark:text-slate-200">إلغاء</button>
                )}
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">ملاحظات للمعمل</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="أي تعليمات إضافية للمعمل..."
              className="w-full border border-slate-200 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            />
          </div>

          <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-100 dark:border-purple-800 rounded-xl px-3 py-2 text-xs text-purple-700 dark:text-purple-400">
            سيتم إرسال نسخة من ملف المريض (التشخيص، المبلغ، الجلسات) إلى المعمل المختار.
          </div>
        </div>

        <div className="flex gap-3 px-5 pb-5">
          <button
            onClick={handleSend}
            disabled={!selectedLabId || sending}
            className="flex-1 flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-medium py-2.5 rounded-xl transition"
          >
            <Send className="w-4 h-4" /> تحويل إلى المعمل
          </button>
          <button onClick={onClose} className="flex-1 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-medium py-2.5 rounded-xl transition">
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
}
