import type { Bill, Salary, Payment, Patient } from '../types';
import { openPrintWindow } from './print';

interface AccountingReportInput {
  clinicName: string;
  from: string; // yyyy-mm-dd
  to: string;   // yyyy-mm-dd
  bills: Bill[];
  salaries: Salary[];
  payments: Payment[];
  patients: Patient[];
}

function inRange(dateStr: string, from: string, to: string): boolean {
  if (!dateStr) return false;
  const d = dateStr.slice(0, 10);
  return (!from || d >= from) && (!to || d <= to);
}

export function printAccountingReport(input: AccountingReportInput): void {
  const { clinicName, from, to, bills, salaries, payments, patients } = input;

  const periodBills = bills.filter((b) => inRange(b.createdAt, from, to));
  const periodSalaries = salaries.filter((s) => inRange(s.paymentDate || s.createdAt, from, to));
  const periodPayments = payments.filter((p) => inRange(p.date, from, to));
  const newPatients = patients.filter((p) => inRange(p.createdAt, from, to));

  const totalRevenue = periodPayments.reduce((s, p) => s + Number(p.amount), 0);
  const totalSalaries = periodSalaries.reduce((s, x) => s + Number(x.paidAmount), 0);
  const totalBillsPaid = periodBills.reduce((s, b) => s + Number(b.paidAmount), 0);
  const totalBillsDue = periodBills.reduce((s, b) => s + (Number(b.totalAmount) - Number(b.paidAmount)), 0);
  const totalExpenses = totalSalaries + totalBillsPaid;
  const netProfit = totalRevenue - totalExpenses;

  const billRows = periodBills
    .map((b) => `<tr><td>${b.billType === 'other' ? b.customTypeName || 'أخرى' : { electricity: 'كهرباء', water: 'ماء', rent: 'إيجار' }[b.billType]}</td><td>${b.period || '—'}</td><td>₪${Number(b.totalAmount).toLocaleString('ar')}</td><td>₪${Number(b.paidAmount).toLocaleString('ar')}</td><td>${b.paymentStatus}</td></tr>`)
    .join('');

  const salaryRows = periodSalaries
    .map((s) => `<tr><td>${s.employeeName}</td><td>₪${Number(s.monthlySalary).toLocaleString('ar')}</td><td>₪${Number(s.paidAmount).toLocaleString('ar')}</td><td>${s.paymentDate || '—'}</td></tr>`)
    .join('');

  const paymentRows = periodPayments
    .map((p) => `<tr><td>${p.date}</td><td>${p.patientName}</td><td>${({ cash: 'كاش', bank_palestine: 'بنك فلسطين', jawwal: 'جوال بي', palpal: 'بال بي' } as Record<string, string>)[p.method] ?? p.method}</td><td>₪${Number(p.amount).toLocaleString('ar')}</td></tr>`)
    .join('');

  const body = `
    <div class="header">
      <div>
        <h1>التقرير المالي الشامل — ${clinicName || 'العيادة'}</h1>
        <p class="muted">الفترة: من ${from || '—'} إلى ${to || '—'}</p>
      </div>
      <div class="muted">تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG')}</div>
    </div>

    <h2>الملخص العام</h2>
    <div class="grid">
      <div class="stat"><div class="v" style="color:#059669">₪ ${totalRevenue.toLocaleString('ar')}</div><div class="l">إجمالي الإيرادات</div></div>
      <div class="stat"><div class="v" style="color:#dc2626">₪ ${totalExpenses.toLocaleString('ar')}</div><div class="l">إجمالي المصاريف</div></div>
      <div class="stat"><div class="v" style="color:${netProfit >= 0 ? '#059669' : '#dc2626'}">₪ ${netProfit.toLocaleString('ar')}</div><div class="l">${netProfit >= 0 ? 'صافي الربح' : 'صافي الخسارة'}</div></div>
      <div class="stat"><div class="v">${newPatients.length}</div><div class="l">مرضى جدد بالفترة</div></div>
    </div>
    <div class="grid">
      <div class="stat"><div class="v">₪ ${totalSalaries.toLocaleString('ar')}</div><div class="l">رواتب مدفوعة</div></div>
      <div class="stat"><div class="v">₪ ${totalBillsPaid.toLocaleString('ar')}</div><div class="l">فواتير مدفوعة</div></div>
      <div class="stat"><div class="v" style="color:#dc2626">₪ ${totalBillsDue.toLocaleString('ar')}</div><div class="l">فواتير متبقية</div></div>
      <div class="stat"><div class="v">${periodPayments.length}</div><div class="l">عدد الدفعات المسجّلة</div></div>
    </div>

    <h2>إيرادات المرضى (الدفعات المسجّلة)</h2>
    ${periodPayments.length === 0 ? '<p class="muted">لا توجد دفعات ضمن هذه الفترة.</p>' : `
    <table><thead><tr><th>التاريخ</th><th>المريض</th><th>طريقة الدفع</th><th>المبلغ</th></tr></thead><tbody>${paymentRows}</tbody></table>`}

    <h2>الرواتب</h2>
    ${periodSalaries.length === 0 ? '<p class="muted">لا توجد رواتب مسجّلة ضمن هذه الفترة.</p>' : `
    <table><thead><tr><th>الموظف</th><th>الراتب الشهري</th><th>المدفوع</th><th>تاريخ الدفع</th></tr></thead><tbody>${salaryRows}</tbody></table>`}

    <h2>الفواتير التشغيلية</h2>
    ${periodBills.length === 0 ? '<p class="muted">لا توجد فواتير مسجّلة ضمن هذه الفترة.</p>' : `
    <table><thead><tr><th>النوع</th><th>الفترة</th><th>الإجمالي</th><th>المدفوع</th><th>الحالة</th></tr></thead><tbody>${billRows}</tbody></table>`}

    <h2>المرضى الجدد بالفترة</h2>
    ${newPatients.length === 0 ? '<p class="muted">لا يوجد مرضى جدد ضمن هذه الفترة.</p>' : `
    <table><thead><tr><th>الاسم</th><th>رقم الملف</th><th>تاريخ التسجيل</th></tr></thead><tbody>${newPatients.map((p) => `<tr><td>${p.fullName}</td><td>#${p.fileNumber}</td><td>${p.createdAt.slice(0, 10)}</td></tr>`).join('')}</tbody></table>`}
  `;

  openPrintWindow('التقرير المالي الشامل', body);
}
