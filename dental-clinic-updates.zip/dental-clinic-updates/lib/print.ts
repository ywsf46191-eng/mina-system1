/** Opens a new window with the given HTML and triggers the browser print
 *  dialog once it has fully loaded. Used for "طباعة الخطة العلاجية" and
 *  "طباعة تقرير الحسابات" — no extra PDF library needed; the user can choose
 *  "Save as PDF" from the native print dialog. */
export function openPrintWindow(title: string, bodyHtml: string): void {
  const win = window.open('', '_blank', 'width=900,height=1000');
  if (!win) {
    alert('الرجاء السماح بالنوافذ المنبثقة (Popups) لتفعيل الطباعة');
    return;
  }
  win.document.open();
  win.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8" />
<title>${title}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; color: #1e293b; padding: 24px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  h2 { font-size: 15px; margin: 24px 0 10px; border-bottom: 2px solid #1e3a8a; padding-bottom: 6px; }
  .muted { color: #64748b; font-size: 12px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #1e3a8a; padding-bottom: 12px; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 8px; }
  th, td { border: 1px solid #cbd5e1; padding: 6px 8px; text-align: right; }
  th { background: #f1f5f9; font-weight: 600; }
  .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 10px 0; }
  .stat { border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; text-align: center; }
  .stat .v { font-size: 16px; font-weight: 700; }
  .stat .l { font-size: 11px; color: #64748b; }
  .tooth { display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 6px; border: 2px solid #94a3b8; font-size: 11px; font-weight: 700; margin: 2px; }
  .tooth.treatment { background: #ef4444; border-color: #dc2626; color: #fff; }
  .tooth.inprogress { background: #fbbf24; border-color: #f59e0b; color: #fff; }
  .tooth.done { background: #10b981; border-color: #059669; color: #fff; }
  .row { display: flex; justify-content: space-between; }
  .jaw-row { display: flex; justify-content: center; flex-wrap: wrap; margin: 4px 0; }
  .quad-label { font-size: 10px; color: #94a3b8; text-align: center; width: 100%; margin-bottom: 2px; }
  .badge { display: inline-block; font-size: 10px; padding: 2px 8px; border-radius: 999px; }
  .badge.red { background:#fee2e2; color:#b91c1c; } .badge.green { background:#d1fae5; color:#047857; } .badge.amber { background:#fef3c7; color:#b45309; }
  @media print { body { padding: 8px; } }
</style>
</head>
<body>
${bodyHtml}
<script>
  window.onload = function () { setTimeout(function () { window.print(); }, 250); };
</script>
</body>
</html>`);
  win.document.close();
}
