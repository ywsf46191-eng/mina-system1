import type { Patient, Payment, ToothState } from '../types';
import { resolveVisualStatus, shortToothLabel } from './teeth';
import { computePatientFinance } from './finance';
import { openPrintWindow } from './print';

/* Same FDI quadrant layout as DentalChart, duplicated here in plain data form
 * so the print window (a standalone document, not a React tree) can render
 * the same tooth map. */
const QUADRANTS: { label: string; teeth: { fdi: string; display: number }[] }[] = [
  { label: 'الفك العلوي — أيمن', teeth: [18, 17, 16, 15, 14, 13, 12, 11].map((d, i) => ({ fdi: String(18 - i), display: d })) },
  { label: 'الفك العلوي — أيسر', teeth: [21, 22, 23, 24, 25, 26, 27, 28].map((fdi, i) => ({ fdi: String(fdi), display: i + 1 })) },
  { label: 'الفك السفلي — أيمن', teeth: [48, 47, 46, 45, 44, 43, 42, 41].map((fdi, i) => ({ fdi: String(fdi), display: 8 - i })) },
  { label: 'الفك السفلي — أيسر', teeth: [31, 32, 33, 34, 35, 36, 37, 38].map((fdi, i) => ({ fdi: String(fdi), display: i + 1 })) },
];

function renderJawHtml(chart: Record<string, ToothState>): string {
  const quadHtml = (q: typeof QUADRANTS[number]) =>
    `<div class="quad-label">${q.label}</div><div class="jaw-row">${q.teeth
      .map(({ fdi, display }) => {
        const status = resolveVisualStatus(chart[fdi]);
        return `<span class="tooth ${status}" title="السن ${fdi}">${display}</span>`;
      })
      .join('')}</div>`;

  return `
    <div style="border:1px solid #cbd5e1;border-radius:12px;padding:14px;background:#f8fafc">
      <div style="display:flex;gap:10px">${quadHtml(QUADRANTS[0])}${quadHtml(QUADRANTS[1])}</div>
      <div style="border-top:2px dashed #cbd5e1;margin:8px 0"></div>
      <div style="display:flex;gap:10px">${quadHtml(QUADRANTS[2])}${quadHtml(QUADRANTS[3])}</div>
      <div style="margin-top:10px;font-size:11px;display:flex;gap:14px;justify-content:center">
        <span><span class="tooth treatment" style="width:14px;height:14px"></span> علاج مطلوب</span>
        <span><span class="tooth inprogress" style="width:14px;height:14px"></span> قيد العلاج</span>
        <span><span class="tooth done" style="width:14px;height:14px"></span> تم العلاج</span>
      </div>
    </div>`;
}

export function printTreatmentPlan(patient: Patient, payments: Payment[] = []): void {
  const chart = patient.dentalChart ?? {};
  const entries = Object.entries(chart).filter(([, s]) => resolveVisualStatus(s) !== 'none');
  const { totalDue, totalPaid, remaining } = computePatientFinance(patient, payments);
  const patientPayments = payments.filter((p) => p.patientId === patient.id).sort((a, b) => a.date.localeCompare(b.date));

  const detailRows = entries
    .map(([fdi, s]) => {
      const status = resolveVisualStatus(s);
      const total = s.totalSessions ?? 1;
      const done = s.completedSessions?.length ?? (status === 'done' ? total : 0);
      const sessionDetails = Array.from({ length: total }, (_, i) => i + 1)
        .map((n) => {
          const isDone = (s.completedSessions ?? []).includes(n);
          const note = s.sessionNotes?.[String(n)];
          return `جلسة ${n}${isDone ? ' ✓' : ''}${note ? `: ${note}` : ''}`;
        })
        .join(' / ');
      const badge = status === 'done' ? '<span class="badge green">تم العلاج</span>'
        : status === 'inprogress' ? '<span class="badge amber">قيد العلاج</span>'
          : '<span class="badge red">علاج مطلوب</span>';
      return `<tr>
        <td>${fdi} (${shortToothLabel(fdi)})</td>
        <td>${s.diagnosis || s.notes || '—'}</td>
        <td>${badge}</td>
        <td>${done}/${total}</td>
        <td style="font-size:10px">${sessionDetails || '—'}</td>
        <td>₪ ${Number(s.amount ?? 0).toLocaleString('ar')}</td>
      </tr>`;
    })
    .join('');

  const paymentRows = patientPayments
    .map((p) => `<tr><td>${p.date}</td><td>${p.note || '—'}</td><td>₪ ${Number(p.amount).toLocaleString('ar')}</td></tr>`)
    .join('');

  const body = `
    <div class="header">
      <div>
        <h1>الخطة العلاجية — ${patient.fullName}</h1>
        <p class="muted">ملف رقم #${patient.fileNumber} · ${patient.phoneNumber} · ${patient.gender === 'male' ? 'ذكر' : 'أنثى'}</p>
      </div>
      <div class="muted">تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG')}</div>
    </div>

    <h2>مخطط الأسنان</h2>
    ${renderJawHtml(chart)}

    <h2>تفاصيل الأسنان التي تحتاج/تلقت علاجاً</h2>
    ${entries.length === 0 ? '<p class="muted">لا توجد أسنان مسجّلة بعد.</p>' : `
    <table>
      <thead><tr><th>السن</th><th>التشخيص</th><th>الحالة</th><th>الجلسات</th><th>تفاصيل الجلسات</th><th>المبلغ</th></tr></thead>
      <tbody>${detailRows}</tbody>
    </table>`}

    <h2>الفاتورة المالية</h2>
    <div class="grid" style="grid-template-columns:repeat(3,1fr)">
      <div class="stat"><div class="v">₪ ${totalDue.toLocaleString('ar')}</div><div class="l">إجمالي المطلوب</div></div>
      <div class="stat"><div class="v" style="color:#059669">₪ ${totalPaid.toLocaleString('ar')}</div><div class="l">إجمالي المدفوع</div></div>
      <div class="stat"><div class="v" style="color:#dc2626">₪ ${remaining.toLocaleString('ar')}</div><div class="l">المتبقي</div></div>
    </div>
    ${patientPayments.length > 0 ? `
    <h2>سجل الدفعات</h2>
    <table>
      <thead><tr><th>التاريخ</th><th>ملاحظة</th><th>المبلغ</th></tr></thead>
      <tbody>${paymentRows}</tbody>
    </table>` : ''}
  `;

  openPrintWindow(`الخطة العلاجية — ${patient.fullName}`, body);
}
