import type {
  Patient, UserProfile, Secretary, DoctorRecord,
  Salary, Bill, BillType, BillStatus, Payment,
  WarehouseItem, WarehouseItemType, ClinicSettings, Branch,
  SmsLogEntry, Lab, LabTransfer, RadiologyImage,
} from '../types';
import { queueSync } from './syncService';

function uid() {
  return crypto.randomUUID();
}

function now() {
  return new Date().toISOString();
}

function getList<T>(key: string): T[] {
  try { return JSON.parse(localStorage.getItem(key) ?? '[]'); }
  catch { return []; }
}

function setList<T>(key: string, list: T[]): void {
  localStorage.setItem(key, JSON.stringify(list));
}

function getObj<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch { return fallback; }
}

function setObj<T>(key: string, val: T): void {
  localStorage.setItem(key, JSON.stringify(val));
}

const K = {
  users: 'dc_users',
  branches: 'dc_branches',
  patients: (clinicId: string) => `dc_patients_${clinicId}`,
  salaries: (clinicId: string) => `dc_salaries_${clinicId}`,
  bills: (clinicId: string) => `dc_bills_${clinicId}`,
  payments: (clinicId: string) => `dc_payments_${clinicId}`,
  warehouse: (clinicId: string) => `dc_wh_${clinicId}`,
  settings: (clinicId: string) => `dc_settings_${clinicId}`,
  smslog: (clinicId: string) => `dc_smslog_${clinicId}`,
  labs: (clinicId: string) => `dc_labs_${clinicId}`,
  labTransfers: (clinicId: string) => `dc_labtransfers_${clinicId}`,
  radiology: (clinicId: string) => `dc_radiology_${clinicId}`,
};

export function initStore(): void {
  const users = getList<UserProfile>(K.users);
  if (!users.find((u) => u.role === 'superadmin')) {
    const admin: UserProfile = {
      uid: 'sa-1',
      email: 'admin@clinic.com',
      password: 'admin123',
      role: 'superadmin',
      clinicId: '',
      displayName: 'المدير العام',
      allowedPages: ['*'],
    };
    setList(K.users, [admin, ...users]);
  }
}

export function getUsers(): UserProfile[] {
  return getList<UserProfile>(K.users);
}

export function getUserById(uid: string): UserProfile | undefined {
  return getUsers().find((u) => u.uid === uid);
}

export function saveUser(user: UserProfile): void {
  const users = getUsers();
  const idx = users.findIndex((u) => u.uid === user.uid);
  if (idx >= 0) users[idx] = user;
  else users.push(user);
  setList(K.users, users);
}

export function deleteUser(uid: string): void {
  setList(K.users, getUsers().filter((u) => u.uid !== uid));
}

export function loginUser(email: string, password: string): UserProfile | null {
  const users = getUsers();
  return users.find((u) => u.email === email && u.password === password) ?? null;
}

export async function createUserProfile(
  newUid: string,
  data: { email: string; role: string; clinicId: string; displayName: string; doctorId?: string; password?: string; allowedPages?: string[] },
): Promise<void> {
  const user: UserProfile = {
    uid: newUid,
    email: data.email,
    password: data.password ?? '',
    role: data.role as UserProfile['role'],
    clinicId: data.clinicId,
    displayName: data.displayName,
    doctorId: data.doctorId,
    allowedPages: data.allowedPages ?? [],
  };
  saveUser(user);
}

export function getBranches(): Branch[] {
  return getList<Branch>(K.branches);
}

export function saveBranch(branch: Branch): void {
  const branches = getBranches();
  const idx = branches.findIndex((b) => b.id === branch.id);
  if (idx >= 0) branches[idx] = branch;
  else branches.push(branch);
  setList(K.branches, branches);
}

export function deleteBranch(id: string): void {
  setList(K.branches, getBranches().filter((b) => b.id !== id));
}

export function createBranchRecord(data: {
  name: string;
  address?: string;
  phone?: string;
  allowedDoctorPages?: string[];
  allowedSecretaryPages?: string[];
}): Branch {
  const branch: Branch = {
    id: uid(),
    name: data.name,
    address: data.address ?? '',
    phone: data.phone ?? '',
    managerIds: [],
    allowedDoctorPages: data.allowedDoctorPages ?? [],
    allowedSecretaryPages: data.allowedSecretaryPages ?? [],
    createdAt: now(),
  };
  saveBranch(branch);
  return branch;
}

export async function getPatients(clinicId: string): Promise<Patient[]> {
  if (!clinicId) return [];
  return getList<Patient>(K.patients(clinicId));
}

export async function createPatient(data: Omit<Patient, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
  const id = uid();
  const patients = getList<Patient>(K.patients(data.clinicId));
  const patient: Patient = { ...data, id, dentalChart: data.dentalChart ?? {}, createdAt: now(), updatedAt: now() };
  setList(K.patients(data.clinicId), [...patients, patient]);
  queueSync(`clinics/${data.clinicId}/patients`, id, patient as unknown as Record<string, unknown>);
  return id;
}

export async function updatePatient(id: string, data: Partial<Patient>): Promise<void> {
  const clinicId = data.clinicId ?? getUsers().find(() => true)?.clinicId ?? '';
  const allClinics = Object.keys(localStorage)
    .filter((k) => k.startsWith('dc_patients_'))
    .map((k) => k.replace('dc_patients_', ''));

  for (const cid of allClinics) {
    const patients = getList<Patient>(K.patients(cid));
    const idx = patients.findIndex((p) => p.id === id);
    if (idx >= 0) {
      patients[idx] = { ...patients[idx], ...data, updatedAt: now() };
      setList(K.patients(cid), patients);
      queueSync(`clinics/${cid}/patients`, id, patients[idx] as unknown as Record<string, unknown>);
      return;
    }
  }
  if (clinicId) {
    const patients = getList<Patient>(K.patients(clinicId));
    const idx = patients.findIndex((p) => p.id === id);
    if (idx >= 0) {
      patients[idx] = { ...patients[idx], ...data, updatedAt: now() };
      setList(K.patients(clinicId), patients);
      queueSync(`clinics/${clinicId}/patients`, id, patients[idx] as unknown as Record<string, unknown>);
    }
  }
}

export async function deletePatient(id: string): Promise<void> {
  const allClinics = Object.keys(localStorage)
    .filter((k) => k.startsWith('dc_patients_'))
    .map((k) => k.replace('dc_patients_', ''));
  for (const cid of allClinics) {
    const patients = getList<Patient>(K.patients(cid));
    const idx = patients.findIndex((p) => p.id === id);
    if (idx >= 0) {
      setList(K.patients(cid), patients.filter((p) => p.id !== id));
      return;
    }
  }
}

export async function getSecretaries(clinicId: string): Promise<Secretary[]> {
  return getUsers()
    .filter((u) => u.role === 'secretary' && u.clinicId === clinicId)
    .map((u) => ({ id: u.uid, uid: u.uid, email: u.email, displayName: u.displayName, clinicId: u.clinicId, doctorId: u.doctorId ?? '', allowedPages: u.allowedPages }));
}

export async function deleteSecretary(id: string): Promise<void> {
  deleteUser(id);
}

export async function getDoctors(clinicId: string): Promise<DoctorRecord[]> {
  return getUsers()
    .filter((u) => u.role === 'doctor' && u.clinicId === clinicId)
    .map((u) => ({ id: u.uid, uid: u.uid, email: u.email, displayName: u.displayName, specialty: '', phone: '', clinicId: u.clinicId, parentDoctorId: u.doctorId ?? '', allowedPages: u.allowedPages }));
}

export async function deleteDoctor(id: string): Promise<void> {
  deleteUser(id);
}

export async function getSalaries(clinicId: string): Promise<Salary[]> {
  return getList<Salary>(K.salaries(clinicId));
}

export async function createSalary(data: Omit<Salary, 'id' | 'createdAt'>): Promise<string> {
  const id = uid();
  const salaries = getList<Salary>(K.salaries(data.clinicId));
  const salary: Salary = { ...data, id, createdAt: now() };
  setList(K.salaries(data.clinicId), [...salaries, salary]);
  return id;
}

export async function deleteSalary(id: string, clinicId: string): Promise<void> {
  setList(K.salaries(clinicId), getList<Salary>(K.salaries(clinicId)).filter((s) => s.id !== id));
}

export async function getBills(clinicId: string): Promise<Bill[]> {
  return getList<Bill>(K.bills(clinicId));
}

export async function createBill(data: Omit<Bill, 'id' | 'createdAt'>): Promise<string> {
  const id = uid();
  const bills = getList<Bill>(K.bills(data.clinicId));
  const bill: Bill = { ...data, id, createdAt: now() };
  setList(K.bills(data.clinicId), [...bills, bill]);
  return id;
}

export async function deleteBill(id: string, clinicId: string): Promise<void> {
  setList(K.bills(clinicId), getList<Bill>(K.bills(clinicId)).filter((b) => b.id !== id));
}

export function getPayments(clinicId: string): Payment[] {
  return getList<Payment>(K.payments(clinicId));
}

export function createPayment(data: Omit<Payment, 'id'>): Payment {
  const id = uid();
  const payments = getList<Payment>(K.payments(data.clinicId));
  const payment: Payment = { ...data, id };
  setList(K.payments(data.clinicId), [...payments, payment]);
  return payment;
}

export function deletePayment(id: string, clinicId: string): void {
  setList(K.payments(clinicId), getList<Payment>(K.payments(clinicId)).filter((p) => p.id !== id));
}

export async function getWarehouseItems(clinicId: string): Promise<WarehouseItem[]> {
  return getList<WarehouseItem>(K.warehouse(clinicId));
}

export async function createWarehouseItem(data: Omit<WarehouseItem, 'id' | 'createdAt'>): Promise<string> {
  const id = uid();
  const items = getList<WarehouseItem>(K.warehouse(data.clinicId));
  const item: WarehouseItem = { ...data, id, createdAt: now() };
  setList(K.warehouse(data.clinicId), [...items, item]);
  return id;
}

export async function deleteWarehouseItem(id: string, clinicId: string): Promise<void> {
  setList(K.warehouse(clinicId), getList<WarehouseItem>(K.warehouse(clinicId)).filter((i) => i.id !== id));
}

export async function updateWarehouseItem(id: string, clinicId: string, data: Partial<WarehouseItem>): Promise<void> {
  const items = getList<WarehouseItem>(K.warehouse(clinicId));
  const idx = items.findIndex((i) => i.id === id);
  if (idx >= 0) {
    items[idx] = { ...items[idx], ...data };
    setList(K.warehouse(clinicId), items);
  }
}

export async function getClinicSettings(clinicId: string): Promise<ClinicSettings> {
  return getObj<ClinicSettings>(K.settings(clinicId), {});
}

export async function saveClinicSettings(clinicId: string, data: Partial<ClinicSettings>): Promise<void> {
  const current = getObj<ClinicSettings>(K.settings(clinicId), {});
  setObj(K.settings(clinicId), { ...current, ...data });
}

export function getSmsLog(clinicId: string): SmsLogEntry[] {
  return getList<SmsLogEntry>(K.smslog(clinicId))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function addSmsLog(entry: Omit<SmsLogEntry, 'id' | 'createdAt'>): SmsLogEntry {
  const e: SmsLogEntry = { ...entry, id: uid(), createdAt: now() };
  const list = getList<SmsLogEntry>(K.smslog(entry.clinicId));
  list.push(e);
  setList(K.smslog(entry.clinicId), list);
  return e;
}

export function deleteSmsLog(id: string, clinicId: string): void {
  setList(K.smslog(clinicId), getList<SmsLogEntry>(K.smslog(clinicId)).filter((e) => e.id !== id));
}

export function clearSmsLog(clinicId: string): void {
  setList(K.smslog(clinicId), []);
}

/* ── Labs ─────────────────────────────────────────────────────────── */

export function getLabs(clinicId: string): Lab[] {
  return getList<Lab>(K.labs(clinicId)).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
}

export function createLab(data: { clinicId: string; name: string; phone?: string; notes?: string }): Lab {
  const lab: Lab = { id: uid(), clinicId: data.clinicId, name: data.name, phone: data.phone ?? '', notes: data.notes ?? '', createdAt: now() };
  setList(K.labs(data.clinicId), [...getList<Lab>(K.labs(data.clinicId)), lab]);
  queueSync(`clinics/${data.clinicId}/labs`, lab.id, lab as unknown as Record<string, unknown>);
  return lab;
}

export function updateLab(id: string, clinicId: string, data: Partial<Lab>): void {
  const labs = getList<Lab>(K.labs(clinicId));
  const idx = labs.findIndex((l) => l.id === id);
  if (idx < 0) return;
  labs[idx] = { ...labs[idx], ...data };
  setList(K.labs(clinicId), labs);
  queueSync(`clinics/${clinicId}/labs`, id, labs[idx] as unknown as Record<string, unknown>);
}

export function deleteLab(id: string, clinicId: string): void {
  setList(K.labs(clinicId), getList<Lab>(K.labs(clinicId)).filter((l) => l.id !== id));
  queueSync(`clinics/${clinicId}/labs`, id, null);
}

/* ── Lab transfers ────────────────────────────────────────────────── */

export function getLabTransfers(clinicId: string): LabTransfer[] {
  return getList<LabTransfer>(K.labTransfers(clinicId)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getLabTransfersForLab(clinicId: string, labId: string): LabTransfer[] {
  return getLabTransfers(clinicId).filter((t) => t.labId === labId);
}

export function getLabTransfersForPatient(clinicId: string, patientId: string): LabTransfer[] {
  return getLabTransfers(clinicId).filter((t) => t.patientId === patientId);
}

export function createLabTransfer(data: Omit<LabTransfer, 'id' | 'createdAt' | 'status'> & { status?: LabTransfer['status'] }): LabTransfer {
  const transfer: LabTransfer = { ...data, id: uid(), status: data.status ?? 'sent', createdAt: now() };
  setList(K.labTransfers(data.clinicId), [...getList<LabTransfer>(K.labTransfers(data.clinicId)), transfer]);
  queueSync(`clinics/${data.clinicId}/labTransfers`, transfer.id, transfer as unknown as Record<string, unknown>);
  return transfer;
}

export function updateLabTransfer(id: string, clinicId: string, data: Partial<LabTransfer>): void {
  const list = getList<LabTransfer>(K.labTransfers(clinicId));
  const idx = list.findIndex((t) => t.id === id);
  if (idx < 0) return;
  list[idx] = { ...list[idx], ...data };
  setList(K.labTransfers(clinicId), list);
  queueSync(`clinics/${clinicId}/labTransfers`, id, list[idx] as unknown as Record<string, unknown>);
}

export function deleteLabTransfer(id: string, clinicId: string): void {
  setList(K.labTransfers(clinicId), getList<LabTransfer>(K.labTransfers(clinicId)).filter((t) => t.id !== id));
  queueSync(`clinics/${clinicId}/labTransfers`, id, null);
}

/* ── Radiology images ─────────────────────────────────────────────── */

export function getRadiologyImages(clinicId: string, patientId?: string): RadiologyImage[] {
  const all = getList<RadiologyImage>(K.radiology(clinicId)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return patientId ? all.filter((r) => r.patientId === patientId) : all;
}

export function addRadiologyImage(data: Omit<RadiologyImage, 'id' | 'createdAt'>): RadiologyImage {
  const img: RadiologyImage = { ...data, id: uid(), createdAt: now() };
  setList(K.radiology(data.clinicId), [...getList<RadiologyImage>(K.radiology(data.clinicId)), img]);
  // Image data can be large (base64); still queued, but skipped from the
  // immediate-push fast path if huge to avoid blocking the UI thread.
  queueSync(`clinics/${data.clinicId}/radiology`, img.id, img as unknown as Record<string, unknown>);
  return img;
}

export function updateRadiologyImage(id: string, clinicId: string, data: Partial<RadiologyImage>): void {
  const list = getList<RadiologyImage>(K.radiology(clinicId));
  const idx = list.findIndex((r) => r.id === id);
  if (idx < 0) return;
  list[idx] = { ...list[idx], ...data };
  setList(K.radiology(clinicId), list);
  queueSync(`clinics/${clinicId}/radiology`, id, list[idx] as unknown as Record<string, unknown>);
}

export function deleteRadiologyImage(id: string, clinicId: string): void {
  setList(K.radiology(clinicId), getList<RadiologyImage>(K.radiology(clinicId)).filter((r) => r.id !== id));
  queueSync(`clinics/${clinicId}/radiology`, id, null);
}
