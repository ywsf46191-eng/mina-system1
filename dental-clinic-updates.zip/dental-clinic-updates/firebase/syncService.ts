/**
 * Offline-first sync layer.
 *
 * The app's source of truth for reads is always `localStorage` (see
 * `firestoreService.ts`) so the UI keeps working with zero latency and with
 * no internet connection at all. This module is a thin best-effort mirror
 * on top of that: whenever a record is created/updated and we are online +
 * Firebase is configured, we push it to Firestore immediately. If we are
 * offline (or Firebase isn't configured yet, or the write fails), the
 * change is appended to a local "pending" queue. A `window` listener
 * flushes that queue automatically the moment the browser comes back
 * online, and a manual `flushSyncQueue()` is also exposed for a "sync now"
 * button in the UI.
 *
 * To activate real Firebase sync, fill in `firebaseConfig` in `config.ts`.
 * Until then, everything still works perfectly locally — this module simply
 * becomes a no-op mirror.
 */
import { firebaseConfig } from './config';

type PendingOp = {
  id: string;
  collectionPath: string; // e.g. clinics/{clinicId}/labs
  docId: string;
  data: Record<string, unknown> | null; // null === delete
  queuedAt: string;
};

const QUEUE_KEY = 'dc_sync_queue';

function isFirebaseConfigured(): boolean {
  return Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
}

function isOnline(): boolean {
  return typeof navigator === 'undefined' ? true : navigator.onLine;
}

function readQueue(): PendingOp[] {
  try { return JSON.parse(localStorage.getItem(QUEUE_KEY) ?? '[]'); }
  catch { return []; }
}

function writeQueue(items: PendingOp[]): void {
  localStorage.setItem(QUEUE_KEY, JSON.stringify(items));
}

export function getPendingSyncCount(): number {
  return readQueue().length;
}

// Lazily-loaded Firestore handle — only imported if/when Firebase is actually
// configured, so the app never pays the bundle cost or throws at startup
// when running purely offline/local.
let firestorePromise: Promise<import('firebase/firestore').Firestore | null> | null = null;

async function getFirestoreInstance(): Promise<import('firebase/firestore').Firestore | null> {
  if (!isFirebaseConfigured()) return null;
  if (!firestorePromise) {
    firestorePromise = (async () => {
      try {
        const { initializeApp, getApps } = await import('firebase/app');
        const { getFirestore, enableIndexedDbPersistence } = await import('firebase/firestore');
        const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
        const db = getFirestore(app);
        try { await enableIndexedDbPersistence(db); } catch { /* multiple tabs etc — non-fatal */ }
        return db;
      } catch (e) {
        console.warn('Firebase unavailable, continuing in local-only mode.', e);
        return null;
      }
    })();
  }
  return firestorePromise;
}

async function pushOne(op: PendingOp): Promise<boolean> {
  const db = await getFirestoreInstance();
  if (!db) return false;
  try {
    const { doc, setDoc, deleteDoc } = await import('firebase/firestore');
    const ref = doc(db, ...(op.collectionPath.split('/') as [string, ...string[]]), op.docId);
    if (op.data === null) await deleteDoc(ref);
    else await setDoc(ref, op.data, { merge: true });
    return true;
  } catch (e) {
    console.warn('Sync push failed, will retry later.', e);
    return false;
  }
}

/** Queue (and best-effort immediately push) a write so it eventually reaches
 *  Firebase, regardless of current connectivity. Safe to call even when
 *  Firebase isn't configured — it then simply becomes a harmless no-op. */
export async function queueSync(
  collectionPath: string,
  docId: string,
  data: Record<string, unknown> | null,
): Promise<void> {
  const op: PendingOp = { id: crypto.randomUUID(), collectionPath, docId, data, queuedAt: new Date().toISOString() };

  if (isOnline() && isFirebaseConfigured()) {
    const ok = await pushOne(op);
    if (ok) return;
  }
  writeQueue([...readQueue(), op]);
}

/** Replay everything pending against Firestore. Call this on reconnect. */
export async function flushSyncQueue(): Promise<void> {
  if (!isOnline() || !isFirebaseConfigured()) return;
  const queue = readQueue();
  if (queue.length === 0) return;
  const remaining: PendingOp[] = [];
  for (const op of queue) {
    const ok = await pushOne(op);
    if (!ok) remaining.push(op);
  }
  writeQueue(remaining);
}

if (typeof window !== 'undefined') {
  window.addEventListener('online', () => { flushSyncQueue(); });
}
